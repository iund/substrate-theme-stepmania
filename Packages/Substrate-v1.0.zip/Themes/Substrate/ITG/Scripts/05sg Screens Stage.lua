Screens.Stage={
		Init=function(s) end,
		On=function(s) end,
		FirstUpdate=function(s) end,
	}