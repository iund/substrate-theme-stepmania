Screens.NameEntry={
		Init=function(s)
			FitScreenToAspect(s)
		end,
		--On=function(s) end, --unused rn
		FirstUpdate=function(s) end,
		Alarm=function() end,-- SetScreen(Branch.Ending()) end,
		Off=function(s) end,
		
	}
