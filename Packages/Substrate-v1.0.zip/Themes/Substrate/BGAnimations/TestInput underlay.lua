return Def.ActorFrame {
	Def.DeviceList {
		Font="Common Normal",
		InitCommand=cmd(x,SCREEN_LEFT+32;y,SCREEN_TOP+72;horizalign,"left";vertalign,"top")
	},

	Def.InputList {
		Font="Common Normal",
		InitCommand=cmd(x,SCREEN_CENTER_X;y,SCREEN_CENTER_Y;zoom,.75)
	},
}

