return Def.Sprite {
--	Texture=GetCurSong():GetBackgroundPath(),
	InitCommand=cmd(stretchtoscreen)
}