--TODO

--Glow red if in danger,
--Flash green if recovered
--Flash red to purple if dead.

return Def.ActorFrame{}