return Def.BitmapText {
	Font="_common semibold black",
	InitCommand=cmd(zoom,.75;y,24)
}
