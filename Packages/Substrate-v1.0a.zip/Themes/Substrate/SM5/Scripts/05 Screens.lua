Screens={}

Screens={

	Boot=function(s)
	end,


	Common={
		Init=function(s) end,
	},
	Attract={
		Init=function(s) end,
	},



}