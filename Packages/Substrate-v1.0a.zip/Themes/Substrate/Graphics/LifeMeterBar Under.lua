return Def.Quad{
	OnCommand=cmd(zoomto,THEME:GetMetric("LifeMeterBar","MeterWidth"),32;diffuse,unpack(UIColors["LifebarBackground"]))
}