return Def.Quad {
	OnCommand=cmd(zoomtowidth,2;zoomtoheight,72;diffusealpha,0.25)
}
