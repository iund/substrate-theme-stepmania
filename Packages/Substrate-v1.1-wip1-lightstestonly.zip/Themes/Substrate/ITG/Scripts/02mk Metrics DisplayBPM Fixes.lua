-- Fix some bad display bpms here:

	SongDisplayBPMs={
		["/Songs/In The Groove/Delirium/"] = {163},
		["/Songs/In The Groove/VerTex/"] = {306}, --before the speed-up
	}
