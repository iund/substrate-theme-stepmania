Screens.Title={
		Join={
			On=function(s) SetEnv('Game',1) end,
			FirstUpdate=function(s) end,
		},
		Menu={
			On=function(s) SetEnv('Game',1) end,
			FirstUpdate=function(s) end,
		},
	}
