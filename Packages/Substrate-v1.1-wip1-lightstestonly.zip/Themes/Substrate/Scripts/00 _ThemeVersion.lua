THEME_VERSION={ MAJOR=1, MINOR=1, SUFFIX_STR="-wip1-lightstestonly" }
