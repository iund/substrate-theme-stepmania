return Def.ActorFrame{
--[[
	Def.Quad{
		InitCommand=cmd(stretchtoscreen;diffuse,0,0,0,0;visible,false),
		MenuTimerWarningMessageCommand=cmd(visible,true;accelerate,5;diffusealpha,1),
		MenuTimerExpiredMessageCommand=cmd(finishtweening)
	}
--]]
}
