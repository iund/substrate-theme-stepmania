_fade in from saving
