return Def.ActorFrame{
	Def.BitmapText{
		Font="Common normal",
		Text="Boot",
		InitCommand=cmd(x,SCREEN_CENTER_X;y,SCREEN_CENTER_Y)
	}
}