return Def.Quad {
--	Texture=GetCurSong():GetBackgroundPath(),
	InitCommand=cmd(visible,false)
}